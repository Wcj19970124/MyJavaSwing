package test;

import af.sql.c3p0.AfSimpleDB;
import entity.Picture;

import java.util.Date;

//单元测试，测试数据库是否连接成功
public class jdbcConnection {
    public static void main(String[] args) throws Exception {
        Picture picture =new Picture();
        picture.setRealName("美丽风景");
        picture.setName("美丽风景");
        picture.setStorePath("/d/image");
        picture.setTag("风景");
        picture.setTimeCreated(new Date());
        picture.setTimeModified(new Date());

        AfSimpleDB.insert(picture);
        System.out.println("插入成功");
    }
}
