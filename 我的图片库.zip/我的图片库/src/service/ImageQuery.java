package service;

import af.sql.c3p0.AfSimpleDB;
import af.sql.util.AfSqlWhere;
import af.web.restful.AfRestfulApi;
import entity.Picture;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

//图片查询服务
public class ImageQuery extends AfRestfulApi {
    @Override
    public Object execute(JSONObject jsonObject) throws Exception {

        //从前端获取当前页码
        int pageNumber = jsonObject.optInt("pageNumber",1);
        //获取数据库中的数据总条数
        int count = getCount("");
        //每页存放的图片个数
        int pageSize = 12;
        //总共的页数,若除整，页码数加一
        int pageCount = count/pageSize;
        if(count % pageSize!=0)
            pageCount+=1;

        //构造条件语句
        AfSqlWhere where = new AfSqlWhere();
        //构造order by语句
        String order = " ORDER BY ID DESC ";
        //构造limit语句
        String limit = String.format(" LIMIT %d,%d",pageSize*(pageNumber-1),pageSize);
        //构造查询语句
        String sql = " select * from picture "
                +where
                +order
                +limit;

        //查询信息
        List<Picture> pictureList = AfSimpleDB.query(sql,Picture.class);
        //url根路径
        String contextPath = httpReq.getContextPath();
        //将页码相关信息放入json对象中和图片信息一块传给前端
        JSONObject jsonObject2 = new JSONObject();
        jsonObject2.put("count",count);
        jsonObject2.put("pageCount",pageCount);
        jsonObject2.put("pageNumber",pageNumber);
        //picture必须为POJO类，否则无法进行转换
        //定义一个存放图片url的JSONArray
        JSONArray pictureUrlArray = new JSONArray();
        //将页码的json对象加入json数组
        jsonObject2.put("pictureUrlArray",pictureUrlArray);
        for(Picture picture:pictureList){

            //获取么一个图片的url，且将其添加进入存放url的array中
            JSONObject jsonObject1 = new JSONObject(picture);
            String url = contextPath+picture.storePath;
            jsonObject1.put("url",url);
            pictureUrlArray.put(jsonObject1);
        }
        return jsonObject2;
    }

    //查询数据库中数据总条数
    public int getCount(String where) throws Exception {

        String sql = "select count(id) from picture" +where;
        String[] row = AfSimpleDB.get(sql);
        if(row!=null)
            return Integer.valueOf(row[0]);
        return 0;
    }
}
