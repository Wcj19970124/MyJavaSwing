package service;

import af.sql.c3p0.AfSimpleDB;
import af.web.restful.AfRestfulApi;
import entity.Picture;
import org.json.JSONObject;

import java.util.Date;

//图片保存服务
public class ImageSave extends AfRestfulApi {
    @Override
    public Object execute(JSONObject jsonObject) throws Exception {

        String storePath = jsonObject.getString("storePath");
        String tag = jsonObject.getString("tag");
        Long size = jsonObject.optLong("size",0L);
        String realName = jsonObject.getString("realName");

        Picture picture = new Picture();
        picture.setStorePath(storePath);
        picture.setTag(tag);
        picture.setSize(size);
        picture.setRealName(realName);
        picture.setName(realName);
        picture.setTimeCreated(new Date());
        picture.setTimeModified(new Date());

        AfSimpleDB.insert(picture);
        System.out.println("图片入库成功！");
        return null;
    }
}
