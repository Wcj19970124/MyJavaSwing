package service;

import af.sql.c3p0.AfSimpleDB;
import af.sql.util.AfSqlWhere;
import af.web.restful.AfRestfulApi;
import org.json.JSONObject;

public class ImageDelete extends AfRestfulApi {
    @Override
    public Object execute(JSONObject jsonObject) throws Exception {

        int id = jsonObject.getInt("id");
        AfSqlWhere where = new AfSqlWhere();
        where.add2("id",id);

        String sql = "delete from picture "+ where;
        AfSimpleDB.execute(sql);
        return null;
    }
}
