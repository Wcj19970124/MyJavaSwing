package service;

import af.web.AfFormData;
import af.web.fileupload.AfUploadHandler;
import af.web.fileupload.AfUploadUtils;
import org.json.JSONObject;

import java.io.File;

//图片上传服务
public class ImageUpload extends AfUploadHandler {
    String tmpFileName;
    @Override
    public File getTmpDir() {
        String path = httpReq.getServletContext().getRealPath("/tmp");
        return new File(path);
    }

    @Override
    public File getTmpFile(File tmpDir, String realName) {
        String suffix = AfUploadUtils.fileSuffix(realName);
        String uuid = AfUploadUtils.createUUID();
        this.tmpFileName = uuid+"."+suffix;
        return new File(tmpDir,tmpFileName);
    }

    @Override
    public Object complete(long l, AfFormData afFormData) {

        String storePath = "/tmp/"+tmpFileName;
        String contextPath = httpReq.getServletContext().getContextPath();
        String url = contextPath+storePath;

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("storePath",storePath);
        jsonObject.put("url",url);
        return jsonObject;
    }
}
