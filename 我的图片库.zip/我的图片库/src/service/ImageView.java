package service;

import af.sql.c3p0.AfSimpleDB;
import af.sql.util.AfSqlWhere;
import af.web.restful.AfRestfulApi;
import entity.Picture;
import org.json.JSONObject;

//图片详情展示服务
public class ImageView extends AfRestfulApi {
    @Override
    public Object execute(JSONObject jsonObject) throws Exception {

        int id = jsonObject.getInt("id");
        AfSqlWhere where = new AfSqlWhere();
        where.add2("id",id);
        String sql = "select * from picture "+ where;

        Picture picture = (Picture)AfSimpleDB.get(sql,Picture.class);
        if(picture==null)
            throw new Exception("无此图片！id="+id);
        JSONObject jsonObject1 = new JSONObject(picture);
        String contextPath = httpReq.getContextPath();
        String url = contextPath+picture.storePath;
        jsonObject1.put("url",url);

        return jsonObject1;
    }
}
