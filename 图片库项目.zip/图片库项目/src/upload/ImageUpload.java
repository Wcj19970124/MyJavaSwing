package upload;

import af.web.AfFormData;
import af.web.fileupload.AfUploadHandler;
import af.web.fileupload.AfUploadUtils;
import org.json.JSONObject;

import java.io.File;

public class ImageUpload extends AfUploadHandler {

    String tmpFileName;
    //生成一个存放图片的目录
    @Override
    public File getTmpDir() {
        String path = httpReq.getServletContext().getRealPath("/tmp");
        return new File(path);
    }

    @Override
    public File getTmpFile(File tmpDir, String realName) {

        String suffix = AfUploadUtils.fileSuffix(realName);
        String uuid = AfUploadUtils.createUUID();
        this.tmpFileName = uuid+"."+suffix;
        return new File(tmpDir,tmpFileName);
    }

    //给浏览器返回一图片链接
    @Override
    public Object complete(long l, AfFormData afFormData) {
        String storePath = "/tmp/"+tmpFileName;
        String contextPath = httpReq.getServletContext().getContextPath();
        String url = contextPath+storePath;

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("storePath",storePath);
        jsonObject.put("url",url);
        return jsonObject;
    }
}
