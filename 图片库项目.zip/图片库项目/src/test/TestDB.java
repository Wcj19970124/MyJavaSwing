package test;

import af.sql.c3p0.AfSimpleDB;
import my.db.Picture;

import java.util.Date;

public class TestDB {
    public static void main(String[] args) {
        Picture picture = new Picture();

        picture.setName("美丽风景.jpg");
        picture.setRealName("美丽风景");
        picture.setStorePath("/img/picture");
        picture.setTag("111");
        picture.setTimeCreated(new Date());
        picture.setTimeModified(new Date());

        try{
            AfSimpleDB.insert(picture);
        }catch(Exception e){
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
    }
}
