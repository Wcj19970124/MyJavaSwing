package test;

import af.sql.c3p0.AfSimpleDB;
import af.sql.util.AfSqlWhere;
import my.db.Picture;

import java.util.List;

//经测试，注意limit语句和order语句之间要有空格，级limit中先空一格
//再写LIMIT 30
public class TestQuery {
    public static void main(String[] args) throws Exception {
        //where子句为空
        AfSqlWhere where = new AfSqlWhere();
        //排序子句
        String order = "ORDER BY ID DESC";
        //显示条数限制
        String limit = " LIMIT 30";

        //查询语句
        String sql = " SELECT * FROM picture"
                +where
                +order
                +limit;

        //查询数据库中的图片
        List<Picture> pictureList = AfSimpleDB.query(sql,Picture.class);

        //输出查询的数据
        for(Picture row:pictureList){
            System.out.println(row);
        }
    }
}
