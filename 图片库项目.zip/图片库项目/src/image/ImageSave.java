package image;

import af.sql.c3p0.AfSimpleDB;
import af.web.restful.AfRestfulApi;
import my.db.Picture;
import org.apache.commons.io.FileUtils;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.Date;

public class ImageSave extends AfRestfulApi {
    @Override
    public Object execute(JSONObject jsonObject) throws Exception {

        //从传回来的数据中获取我们想要保存在数据库中的数据
        String tmpPath = jsonObject.getString("tmpPath");
        String tag = jsonObject.getString("tag");
        Long size= jsonObject.optLong("size",0L);
        String realName = jsonObject.optString("realName");

        //移动文件：将图片从tmp目录移动自data目录
        String storePath = moveFile(tmpPath);

        //将图片信息存储到picture对象中去
        Picture picture = new Picture();
        picture.setName(jsonObject.optString("realName",""));
        picture.setRealName(jsonObject.optString("realName",""));
        picture.setSize(size);
        picture.setStorePath(storePath);
        picture.setTag(tag);
        picture.setTimeCreated(new Date());
        picture.setTimeModified(new Date());

        //将图片信息插入到数据库中
        AfSimpleDB.insert(picture);
        //System.out.println("保存图片成功");
        return null;
    }
    private String moveFile(String tmpPath) throws IOException {

        String docBase = httpReq.getServletContext().getRealPath("/");
        File docBaseDir = new File(docBase);

        //获取源文件
        File srcFile = new File(docBaseDir,tmpPath);//找到临时路径下的文件
        String fileName = srcFile.getName();//获取临时路径下存储图片的文件名

        //创建目标文件
        File dstDir = new File(docBaseDir,"data");
        dstDir.mkdirs();

        //转移文件:从文件源目录到目标目录
        FileUtils.moveFileToDirectory(srcFile,dstDir,true);

        //返回该文件下的图片的地址
        return "/data/"+fileName;


    }
}
