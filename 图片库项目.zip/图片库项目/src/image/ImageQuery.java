package image;

import af.sql.c3p0.AfSimpleDB;
import af.sql.util.AfSqlWhere;
import af.web.restful.AfRestfulApi;
import my.db.Picture;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

public class ImageQuery extends AfRestfulApi {
    @Override
    public Object execute(JSONObject jsonObject) throws Exception {

        //从前端获取当前页面
        int pageNumber = jsonObject.optInt("pageNumber",1);

        //定义页面的各种参数
        //获取数据库中一共有多少条图片信息
        int count = getCount("");
        //前端页面每一页存放12条图片信息
        int pageSize = 12;
        //一共有多少页
        int pageCount = count/pageSize;
        //如果图片信息总数除以每页的信息数余数不为0，则页数加1
        if(count % pageSize!=0)
            pageCount+=1;

        //where子句为空
        AfSqlWhere where = new AfSqlWhere();
        //排序子句
        String order = "ORDER BY ID DESC";
        //显示条数限制(第一个参数表示从第多少条开始，第二个参数表示显示多少条数据）
        String limit = String.format(" LIMIT %d,%d",pageSize*(pageNumber-1),pageSize);
        //查询语句
        String sql = " SELECT * FROM picture"
                +where
                +order
                +limit;

        //查询数据库中的图片
        List<Picture> pictureList = AfSimpleDB.query(sql,Picture.class);

        //将图片转换成前台需要的数据并返回
        String contextPath = httpReq.getContextPath();

        JSONObject jsonObject2 = new JSONObject();
        jsonObject2.put("count",count);
        jsonObject2.put("pageNumber",pageNumber);
        jsonObject2.put("pageCount",pageCount);

        JSONArray pictureArray = new JSONArray();
        jsonObject2.put("pictureArray",pictureArray);
        for(Picture picture:pictureList){

            JSONObject jsonObject1 = new JSONObject(picture);
            String url = contextPath+picture.storePath;
            jsonObject1.put("url",url);
            pictureArray.put(jsonObject1);
        }
        //System.out.println("读取数据成功");
        return jsonObject2;
    }
    //查询数据库中一共有多少条数据
    public int getCount(String where) throws Exception {

        String sql = "select count(id) from picture "+ where;
        String[] row = AfSimpleDB.get(sql);
        if(row!=null){
            return Integer.valueOf(row[0]);
        }
        return 0;
    }
}
